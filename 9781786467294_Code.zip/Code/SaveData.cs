﻿using System.Collections.Generic;
using UnityEngine;
using System.Xml.Serialization;
using System.IO;

public class SaveData : MonoBehaviour {

    [XmlRoot("SavedData")]

    [System.Serializable]
    public struct DataTransform
    {
        public float X;
        public float Y;
        public float Z;
        public float RotX;
        public float RotY;
        public float RotZ;
        public float ScaleX;
        public float ScaleY;
        public float ScaleZ;
    }

    public class EnemyData
    {
        public DataTransform Tranformation;
        public bool Armed = false;

    }

    public class Playerdata
    {
        public DataTransform PlayerTransform;

    }

    public class SavedData
    {
        // enemy
        public List<EnemyData> Enemies = new List<EnemyData>();

        // main gamer data
        public Playerdata PD = new Playerdata();
    }

    public SavedData SD = new SavedData();

    public void Save(string FileName = "SavedData.xml")
    {
        XmlSerializer Serializer = new XmlSerializer(typeof(SavedData));
        FileStream Stream = new FileStream(FileName, FileMode.Create);
        Serializer.Serialize(Stream, SD);
        Stream.Close();
    }

    public void Load(string FileName = "SavedData.xml")
    {
        XmlSerializer Serializer = new XmlSerializer(typeof(SavedData));
        FileStream Stream = new FileStream(FileName, FileMode.Open);
        SD = Serializer.Deserialize(Stream) as SavedData;
        Stream.Close();
    }
}
