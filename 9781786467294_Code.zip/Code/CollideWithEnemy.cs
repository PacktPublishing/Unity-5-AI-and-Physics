﻿using UnityEngine;

public class CollideWithEnemy : MonoBehaviour {

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Enemy")
        {
            ScoreManager.currentScore = ScoreManager.currentScore - 20;
        }
    }
}
