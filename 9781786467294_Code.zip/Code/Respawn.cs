﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Respawn : MonoBehaviour {

    public Vector3 spawnPoint;

    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Enemy")
        {
            this.transform.position = spawnPoint;
        }
    }
 
}
