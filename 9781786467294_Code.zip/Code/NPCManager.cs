﻿using UnityEngine;
using UnityEngine.UI;

public class NPCManager : MonoBehaviour
{
    public static int npcHealth = 100;
    public GameObject player;
    public Slider npcHealthBar;

    
    // Update is called once per frame
    void Update()
    {
        npcHealthBar.value = npcHealth;
    }
}
