﻿using UnityEngine;

public class NPCLoseHealth : MonoBehaviour {

    void OnTriggerEnter(Collider other)
    {
        // Projectile hits Enemy; add 20 points
        ScoreManager.currentScore = ScoreManager.currentScore + 20;

        NPCManager.npcHealth -= 20;
        if (NPCManager.npcHealth < 0)
            NPCManager.npcHealth = 0;
    }
}
