﻿using UnityEngine;

public class LoseHealth : MonoBehaviour {

    void OnTriggerEnter(Collider other)
    {
        // Lava pad engaged; subtract 100 points
        ScoreManager.currentScore = ScoreManager.currentScore -100;

        PlayerManager.health -= 20;
        if (PlayerManager.health < 0)
            PlayerManager.health = 0;
    }

}
