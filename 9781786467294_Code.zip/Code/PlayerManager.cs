﻿using UnityEngine;
using UnityEngine.UI;

public class PlayerManager : MonoBehaviour {

    public static int health = 100;
    public GameObject player;
    public Slider healthBar;

    void ReduceHealth()  {
        health = health - 5;
        healthBar.value = health;
        if(health <= 0) {
            // defeat
            Debug.Log("Player died."); }
    }
	// Update is called once per frame
	void Update () {
        healthBar.value = health; }
}
