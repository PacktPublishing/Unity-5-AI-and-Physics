﻿using UnityEngine;

public class DestroySphere : MonoBehaviour {

    void OnCollisionEnter(Collision whatICollidedWith)
    {
        if (whatICollidedWith.gameObject.name == "FPSController")
        {
            Destroy(gameObject);
            Debug.Log("Another sphere has been destroyed!");
        }
    }

}
