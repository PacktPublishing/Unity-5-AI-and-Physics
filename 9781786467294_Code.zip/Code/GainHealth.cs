﻿using UnityEngine;

public class GainHealth : MonoBehaviour {

    void OnTriggerEnter(Collider other)
    {
        // Health pad engaged; add 3 points
        ScoreManager.currentScore = ScoreManager.currentScore + 3;

        PlayerManager.health += 20;
        Destroy(this.gameObject);
    }


}
